const user = require('./user');
const course = require('./course');
const home = require('./home');

module.exports = {
    user,
    home,
    course
};