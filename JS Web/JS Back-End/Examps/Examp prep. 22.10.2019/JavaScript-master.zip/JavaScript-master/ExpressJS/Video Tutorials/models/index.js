const User = require('./User');
const Course = require('./Course');

module.exports = {
    User,
    Course
};