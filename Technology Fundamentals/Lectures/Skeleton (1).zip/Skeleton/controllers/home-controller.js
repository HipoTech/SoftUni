module.exports = {
  getIndex: function (req, res) {
    //TODO
  },
  getCreate: function (req, res) {
    //TODO
  },
  postCreate: function (req, res) {
    //TODO
  },
  getEdit: function (req, res) {
    //TODO
  },
  postEdit: function (req, res) {
    //TODO
  },
  getDelete: function (req, res) {
    //TODO
  },
  postDelete: function (req, res) {
    //TODO
  }
};